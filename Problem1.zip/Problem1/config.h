
// Controller connectivity
#define RLED 5
#define UC_LED 13


// target system constants
#define RLED_ON    HIGH
#define RLED_OFF   LOW
#define UC_LED_ON  HIGH
#define UC_LED_OFF LOW


